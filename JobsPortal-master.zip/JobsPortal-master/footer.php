<div class="footer_bottom">	
  <div class="container">
   
  	<div class="clearfix"> </div>
	<div class="copy">
		<p> All &copy; Rights Reserved . Designed by Mighty Sggs'ans </p>
	</div>
  </div>
</div>