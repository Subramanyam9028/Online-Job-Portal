<?php

$con = mysqli_connect('localhost','root','','jobportal');


if(!$con){
    die('cannot connected');
}

?>